%% BISMILLAHIRRAHMAANIRRAHIM
% This code provides the simulation of Q(t) once vaccine is implemeted
% (AGE STRUCTURED MODEL: VACCINE IN JANUARY 2021) 


clear all;
clc;
close all
global N mu pi contact p NumStructur ts gamma delta quar eta  beta_connecticut ActiveCasesData RecoveredData DeathData zeta

%% Data 
DATA = load('Data\DKI Jakarta.txt');
ActiveCasesData = DATA(:,4);
DeathData = DATA(:,6);
RecoveredData = DATA(:,5);

%% Hyperparameters
N = sum(DATA(1,3:6));
ts = length(DATA)+74;
eta = 0.8;
NumStructur = 5; %number of age structur
% rerata (((1)/(70*365))/NumStructur)
pi = (((1)/(70*365))/NumStructur)*ones(NumStructur,1);
mu = (((1)/(70*365))/NumStructur)*ones(NumStructur,1);
zeta = (1/((5/12)*365))*ones(NumStructur,1);

%% Parameters
beta_connecticut = [0.0225; 0.0319; 0.1007; 0.1516; 0.4029];
contact = [5.23, 1.23, 4.05, 0.55, 0.92; ...
    1.17, 8.03, 4.54, 0.86, 1.16;...
    1.43, 1.50, 6.54, 1.55, 1.86;...
    0.60, 0.70, 3.71, 1.90, 1.95;...
    0.36, 0.33, 2.00, 1.09, 2.33]; %contact matrix retrieved from []
p = 0;%probability for wearing mask, sanitized hands, etc.
quar = 0.4*ones(NumStructur,1);
DeathRateTotal = 0.0028; %by fitting to SIRD model non age-structured
delta = DeathRateTotal*ones(NumStructur,1);
RecoveryRateTotal = 0.0875; %by fitting to SIRD model non age-structured 0.0359
gamma = (RecoveryRateTotal)*ones(NumStructur,1); %constant recovery assumption
v = 0*ones(NumStructur,1); %novaccine at first


%first try
PropInfConnecticut = [0.0727; 0.1583; 2.0355; 0.8440; 1.9222]; %retrived from the connecticur data
I0 = (PropInfConnecticut./sum(PropInfConnecticut)).*65.8991; %estimation of the intitial condition
Q0 = (PropInfConnecticut./sum(PropInfConnecticut)).*ActiveCasesData(1);
R0 = (DATA(1,5)/NumStructur)*ones(NumStructur,1);
D0 = (DATA(1,6)/NumStructur)*ones(NumStructur,1);
Spop = [1833306; 1475826; 5275354; 1057741; 792874];
S0 = Spop - Q0 - I0 - R0 - D0;
y0 = [S0;I0;Q0;R0;D0;R0;zeros(5,1)]; %initial conditions
tspan = 1:1:ts;
Min_Par = 0.7906;
parbeta = Min_Par*(beta_connecticut./sum(beta_connecticut));;

%% projection
v = [0;0;0;0;0];
t_proj = 1500;
tspan = 1 : 1: t_proj;
y0 = [S0;I0;Q0;R0;D0;R0;zeros(5,1)]; %initial conditions
[t,y] = ode45(@(t,y) Age5StructuredFun(t,y,parbeta,v),tspan, y0);
yp = y;
tdp  = datetime(2020,DATA(1,2),DATA(1,1)) + caldays(0:1500-1);
%% vaccination
%% Vaksinasi Skenario 1
v = [0;0;0;0;0];
tspan1 = 1 : 1: ts;
NumPeriod = 12;
y0 = [S0;I0;Q0;R0;D0;R0;zeros(5,1)]; %initial conditions
[t,y] = ode45(@(t,y) Age5StructuredFun(t,y,parbeta,v),tspan1, y0);
yv1 = y; 
% results Non_Age_Structured_Vaccine_Estimator_January_2021.m
vacc_rate = [0.0031, 0.0006, 0.0001, 0.0010, 0.0014, 0.0022, 0.0010, 0.0002, 0.0004, 0.0023, 0.0030, 0.0009];
v = zeros(NumStructur,NumPeriod); %initial vaccine

%% VACCINE GIVEN TO ALL AGES
% v(1,:) = vacc_rate;
% v(2,:) = vacc_rate;
% v(3,:) = vacc_rate;
% v(4,:) = vacc_rate;
% v(5,:) = vacc_rate;

%% VACCINE GIVEN WITH ALTERNATING PATTERN
% v(3:5,1) = [vacc_rate(1);vacc_rate(1);vacc_rate(1)];
% v(1:2,2) = [vacc_rate(2);vacc_rate(2)];
% v(3:5,3) = [vacc_rate(3);vacc_rate(3);vacc_rate(3)];
% v(1:2,4) = [vacc_rate(4);vacc_rate(4)];
% v(3:5,5) = [vacc_rate(5);vacc_rate(5);vacc_rate(5)];
% v(1:2,6) = [vacc_rate(6);vacc_rate(6)];
% v(3:5,7) = [vacc_rate(7);vacc_rate(7);vacc_rate(7)];
% v(1:2,8) = [vacc_rate(8);vacc_rate(8)];
% v(3:5,9) = [vacc_rate(9);vacc_rate(9);vacc_rate(9)];
% v(1:2,10) = [vacc_rate(10);vacc_rate(10)];
% v(3:5,11) = [vacc_rate(11);vacc_rate(11);vacc_rate(11)];
% v(1:2,12) = [vacc_rate(12);vacc_rate(12)];

%% VACCINE GIVEN BY PRIORITIZING 20 Y.O. AND YOUNGER
% v(3:5,7:12) = [vacc_rate(7:12);vacc_rate(7:12);vacc_rate(7:12)];
% v(1:2,1:6) = [vacc_rate(1:6);vacc_rate(1:6)];

%% VACCINE GIVEN BY PRIORITIZING ACTIVE AND OLDER PEOPLE
% v(1:2,7:12) = [vacc_rate(7:12);vacc_rate(7:12)];
% v(3:5,1:6) = [vacc_rate(1:6);vacc_rate(1:6);vacc_rate(1:6)];

%% VACCINE GIVEN USING GOV.'S PLAN
v(3,1:12) = [vacc_rate(1:end)];



figure
hold on
imagesc(v);
plot([0.5,0.5],[0.5,5.5],'k','LineWidth',1)
plot([1.5,1.5],[0.5,5.5],'k','LineWidth',1)
plot([2.5,2.5],[0.5,5.5],'k','LineWidth',1)
plot([3.5,3.5],[0.5,5.5],'k','LineWidth',1)
plot([4.5,4.5],[0.5,5.5],'k','LineWidth',1)
plot([5.5,5.5],[0.5,5.5],'k','LineWidth',1)
plot([6.5,6.5],[0.5,5.5],'k','LineWidth',1)
plot([7.5,7.5],[0.5,5.5],'k','LineWidth',1)
plot([8.5,8.5],[0.5,5.5],'k','LineWidth',1)
plot([9.5,9.5],[0.5,5.5],'k','LineWidth',1)
plot([10.5,10.5],[0.5,5.5],'k','LineWidth',1)
plot([11.5,11.5],[0.5,5.5],'k','LineWidth',1)
plot([12.5,12.5],[0.5,5.5],'k','LineWidth',1)
plot(0.5:1:12.5, 0.5*ones(13,1),'k','LineWidth',1)
plot(0.5:1:12.5, 1.5*ones(13,1),'k','LineWidth',1)
plot(0.5:1:12.5, 2.5*ones(13,1),'k','LineWidth',1)
plot(0.5:1:12.5, 3.5*ones(13,1),'k','LineWidth',1)
plot(0.5:1:12.5, 4.5*ones(13,1),'k','LineWidth',1)
plot(0.5:1:12.5, 5.5*ones(13,1),'k','LineWidth',1)
hold off
axis image
axis ij
colorbar
colormap(flipud(gray))
title('Vaccination Rate (1/day)')
xlabel('Period')
ylabel('Age group')

for i = 1 : NumPeriod
   tspansim = 1 : 31; %add 1 more
   y0 = yv1(end,:);
   [t,y] = ode45(@(t,y) Age5StructuredFun(t,y,parbeta,v(:,i)),tspansim, y0);
   yv1 = [yv1;y(2:end,:)];
end
figure;
hold on
tdv1  = datetime(2020,DATA(1,2),DATA(1,1)) + caldays(0:NumPeriod*30+ts-1);
plot(tdp,yp(:,11)+yp(:,12)+yp(:,13)+yp(:,14)+yp(:,15),'r-','LineWidth',2)
plot(tdv1,yv1(:,11)+yv1(:,12)+yv1(:,13)+yv1(:,14)+yv1(:,15),'r-.','LineWidth',2)
% plot(tdv1(1:ts),ActiveCasesData,'ro','LineWidth',2)
plot(tdp,yp(:,21)+yp(:,22)+yp(:,23)+yp(:,24)+yp(:,25),'k-','LineWidth',2)
plot(tdv1,yv1(:,21)+yv1(:,22)+yv1(:,23)+yv1(:,24)+yv1(:,25),'k-.','LineWidth',2)
% plot(tdp(1:ts),,'ko','LineWidth',2)
plot([tdv1(ts),tdv1(ts)],[0,1e9],'k--','LineWidth',1)
hold off
grid on
grid minor
xlim([tdv1(1),tdv1(end)])
legend('Q(t) (No Vaccine)','Q(t) (With Vaccine)','D(t) (No Vaccine)','D(t) (With Vaccine)','location','northwest')
xlabel('DATE')
ylabel('NUMBER OF PEOPLE')
ylim([0,1.2*max(yp(:,11)+yp(:,12)+yp(:,13)+yp(:,14)+yp(:,15))])
title('Projection of The Total Active Cases')



figure;
hold on
tdv1  = datetime(2020,DATA(1,2),DATA(1,1)) + caldays(0:NumPeriod*30+ts-1);
plot(tdp,yp(:,11),'c','LineWidth',2)
plot(tdp,yp(:,12),'b','LineWidth',2)
plot(tdp,yp(:,13),'r','LineWidth',2)
plot(tdp,yp(:,14),'m','LineWidth',2)
plot(tdp,yp(:,15),'k','LineWidth',2)
plot(tdv1,yv1(:,11),'c--','LineWidth',2)
plot(tdv1,yv1(:,12),'b--','LineWidth',2)
plot(tdv1,yv1(:,13),'r--','LineWidth',2)
plot(tdv1,yv1(:,14),'m--','LineWidth',2)
plot(tdv1,yv1(:,15),'k--','LineWidth',2)
plot([tdv1(ts),tdv1(ts)],[0,1e9],'k--','LineWidth',1)
hold off
grid on
grid minor
xlim([tdv1(1),tdv1(end)])
legend('Q1 (0-9)','Q2 (10-19)','Q3 (20-49)','Q4 (50-59)','Q5 (>60)','location','northeast')
xlabel('DATE')
ylabel('NUMBER OF PEOPLE')
ylim([0,1.2*max(yp(:,13))])
title('Projection of The Total Active Cases')




%% Supplementary Functions

%%
function dydt = Age5StructuredFun(t,y,beta,v)
global N contact NumStructur mu pi gamma delta quar zeta eta
dydt = zeros(NumStructur*7,1); % Si Ii Qi R D CIi
idx = 1;
    VirusTransmission = zeros(NumStructur,1); %ngitung sigma kontak dulu
    for j = 1 : NumStructur
        temp = 0;
        for i = 1 : NumStructur
            temp = temp + beta(j)*contact(j,i)*y(NumStructur+i);
        end
        VirusTransmission(j) = temp;
    end
    
for j = 1 : NumStructur %assigning the value of dS_i/dt
    dydt(idx) = pi(j)*(y(j)+y(NumStructur+j)+y(2*NumStructur+j)+y(3*NumStructur+j)) - y(j)*VirusTransmission(j)/(N) - mu(j)*y(j) - eta*v(j)*y(j) + zeta(j)*y(3*NumStructur+j);
    idx = idx+1;
end
for j = 1 : NumStructur %assigning the value of dI_i/dt
    dydt(idx) = y(j)*VirusTransmission(j)/(N) - (quar(j)+mu(j))*y(NumStructur+j);
    idx = idx+1;
end
for j = 1 : NumStructur %assigning the value of dQ_i/dt
    dydt(idx) = quar(j)*y(NumStructur+j) - (gamma(j)+delta(j)+mu(j))*y(2*NumStructur+j);
    idx = idx+1;
end
for j = 1 : NumStructur %assigning the value of dR_i/dt
    dydt(idx) = eta*v(j)*y(j) + gamma(j)*y(2*NumStructur+j) - (mu(j)+zeta(j))*y(3*NumStructur+j);
    idx = idx+1;
end
for j = 1 : NumStructur %assigning the value of dD_i/dt
    dydt(idx) = delta(j)*y(2*NumStructur+j);
    idx = idx+1;
end
for j = 1 : NumStructur %assigning the value of dCR_i/dt
    dydt(idx) = gamma(j)*y(2*NumStructur+j);
    idx = idx+1;
end
for j = 1 : NumStructur %assigning the value of V
    dydt(idx) = v(j)*y(j);
    idx = idx+1;
end

end



