% This code provides the dynamics Q(t) once the quarantine rate and vaccine
% efficacy are varied.

%% ------------------------------------------------------------------------
% Main code begins here

clear all;
clc
close all
global N beta gamma mu delta zeta eta

%previous results
eta = 0.8;
beta = 0.4216;
gamma = 0.0876;
delta = 0.0028;
quar = 0.4000;
I0 = 65.8991;
zeta = 1/((5/12)*365);
%% Input Data
DATA = load('Data/DKI Jakarta.txt');
AC = DATA(:,4);
CR = DATA(:,5);
CD = DATA(:,6);
N = sum(DATA(1,3:6));
v = 0; %no vaccine at first
ts = length(DATA);
td = datetime(2020,DATA(1,2),DATA(1,1))+caldays(0:ts-1);
mu = 1/(70*365); %death and birth rate of human

%% hyperparameters
VaccPeriod = 12; %months
MaxHealthCare = 60e3; % person


%% Vaccination estimation
% before vacccination
tspan=1:1:ts;
y0 = [N-I0-AC(1)-CR(1)-CD(1), I0, AC(1), CR(1), CD(1), CR(1), 0]; %initial condition of the system
[t,y] = ode45(@(t,y) system_function(t,y,0,quar), tspan, y0);
S = y(:,1); I = y(:,2); Q = y(:,3); R = y(:,4); D = y(:,5); CR = y(:,6); V = y(:,7);%assigning the simulation result to variable SIRD


% Selecting the Initial Guess of the optimization process


Min_Vaccine = [0.0019, 0.0007, 0.0015, 0.0004, 0.0004, 0.0003, 0.0025, 0.0004, 0.0003, 0.0003, 0.0009, 0.0004];
%%
eff = [0.5, 0.6, 0.7, 0.8, 0.9]; %vaccine efficacy variation
eta = 0.8;

quar = [0.39, 0.395, 0.400, 0.405,  0.400]; %quarantine rate variation
y00 = [N-I(end)-R(end)-Q(end)-D(end),I(end),Q(end),R(end),D(end),CR(end),V(end)];
for iii = 1 : 5
tspan_Periodically = 1:1:31; % monthly (30 days)
Ext = 0; 
Vacc_eff = eff(iii)*Min_Vaccine;
for jj = 1 : VaccPeriod+Ext
    if jj == 1
        y0 = y00;
    else  
        y0 = [N-I(end)-R(end)-Q(end)-D(end),I(end),Q(end),R(end),D(end),CR(end),V(end)];
    end
         % initial condition
        [t,y] = ode45(@(t,y) system_function(t,y,Vacc_eff(jj),quar(3)), tspan_Periodically, y0);
        S = [S;y(2:end,1)]; 
        I = [I;y(2:end,2)]; 
        Q = [Q;y(2:end,3)]; 
        R = [R;y(2:end,4)];
        D = [D;y(2:end,5)];
        CR = [CR;y(2:end,6)];
        V = [V;y(2:end,7)]; 
end
end
Q1 = [Q(1:ts);Q(ts+1:ts+(VaccPeriod+Ext)*30)];
Q2 = [Q(1:ts);Q(ts+(VaccPeriod+Ext)*30+1:ts+2*(VaccPeriod+Ext)*30)];
Q3 = [Q(1:ts);Q(ts+2*(VaccPeriod+Ext)*30+1:ts+3*(VaccPeriod+Ext)*30)];
Q4 = [Q(1:ts);Q(ts+3*(VaccPeriod+Ext)*30+1:ts+4*(VaccPeriod+Ext)*30)];
Q5 = [Q(1:ts);Q(ts+4*(VaccPeriod+Ext)*30+1:ts+5*(VaccPeriod+Ext)*30)];

%%
close all
 td = datetime(2020,DATA(1,2),DATA(1,1))+caldays(0:ts+(VaccPeriod+Ext)*30-1); %date array
hold on
plot(td,Q1,'LineWidth',2)
plot(td,Q2,'LineWidth',2)
plot(td,Q3,'LineWidth',2)
plot(td,Q4,'LineWidth',2)
plot(td,Q5,'LineWidth',2)
plot([td(ts),td(ts)],[0,1e9],'k','LineWidth',2)
t = text(td(ts)-25,1.5e4,[{'Vaccination begins'}])
t.Rotation = 90;
grid on
grid minor
xlim([td(1),td(end)])
ylim([0,1.2*max(Q1)])
xlabel('date')
ylabel('number of active cases')
% legend('q=0.390','q=0.395','q=0.400','q=0.405','q=0.410','location','northwest')
 legend('Vaccine Efficacy: 50%','Vaccine Efficacy: 60%','Vaccine Efficacy: 70%','Vaccine Efficacy: 80%','Vaccine Efficacy: 90%','location','northwest')
hold off

% Main code ends here
%% --------------------------------------------------------------
% Supplementary Functions
% ---------------------------------------------------------------

function dydt = system_function(t,y,v,quar)
% this function defines the mathematical model of SIQRD
global N mu zeta beta gamma delta eta
dydt = zeros(7,1);
eta = 0.8;
dydt(1) = mu*(y(1)+y(2)+y(3)+y(4)) - beta*(y(1)*y(2))/N - eta*v*y(1) - mu*y(1) + zeta*y(4);
dydt(2) = beta*(y(1)*y(2))/N - quar*y(2) - mu*y(2);
dydt(3) = quar*y(2) - (gamma + delta)*y(3)-mu*y(3) ;
dydt(4) = gamma*y(3) + eta*v*y(1)-mu*y(4) - zeta*y(4);
dydt(5) = delta*y(3);
dydt(6) = gamma*y(3);
dydt(7) = v*y(1);
end

function VaccineTotalCost = cost_function(v,S,I,Q,R,D,CR,V,VaccPeriod,MaxHealthCare)
% This function evaluates the cost function
    global N
    VaccinePrice = 1; % this is assumed
    VaccineTotalPeople = 0; % number of people getting vaccinated on peroid-i
    VaccineTotalPeople_prev = 0; % number of people getting vaccinated on peroid-(i-1). ...
    %This is defined since we have cummulative vaccinated people. So, to
    %calculate #vaccinated person in period i, we simply can calculate the
    %difference.
    tspan = 1:1:31;
    for j = 1 : VaccPeriod
        y0 = [N-I(end)-R(end)-Q(end)-D(end),I(end),Q(end),R(end),D(end),CR(end),V(end)]; %simulation
        [t,y] = ode45(@(t,y) system_function(t,y,v(j)), tspan, y0);
        S = [S;y(2:end,1)]; 
        I = [I;y(2:end,2)]; 
        Q = [Q;y(2:end,3)]; 
        R = [R;y(2:end,4)]; 
        D = [D;y(2:end,5)];
        CR = [CR;y(2:end,6)];
        V = [V;y(2:end,7)];
        VaccineTotalPeople = VaccineTotalPeople + V(end) - VaccineTotalPeople_prev; %calculating the vaccinated person
        VaccineTotalPeople_prev = V(end);
    end
    if (max(Q) >= MaxHealthCare)%omitting the unfeasible solution
        VaccineTotalCost = 1e1000; % by making the VaccineTotalCost as large as possible
    else
        VaccineTotalCost = VaccinePrice*VaccineTotalPeople;
    end
end