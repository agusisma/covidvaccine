
% This code provides the age-group SIQRD parameters estimation

clear all;
clc;
close all
global N mu pi contact p NumStructur ts gamma delta quar eta  beta_connecticut ActiveCasesData RecoveredData DeathData zeta

%% Data 
DATA = load('Data\Jawa Barat.txt');
ActiveCasesData = DATA(:,4);
DeathData = DATA(:,6);
RecoveredData = DATA(:,5);

%% Hyperparameters
N = sum(DATA(1,3:6));
ts = length(DATA);
eta = 0.8;
NumStructur = 5; %number of age structur
% rerata (((1)/(70*365))/NumStructur)
pi = (((1)/(70*365))/NumStructur)*ones(NumStructur,1);
mu = (((1)/(70*365))/NumStructur)*ones(NumStructur,1);
zeta = (1/((5/12)*365))*ones(NumStructur,1);

%% Parameters
beta_connecticut = [0.0225; 0.0319; 0.1007; 0.1516; 0.4029];
contact = [5.23, 1.23, 4.05, 0.55, 0.92; ...
    1.17, 8.03, 4.54, 0.86, 1.16;...
    1.43, 1.50, 6.54, 1.55, 1.86;...
    0.60, 0.70, 3.71, 1.90, 1.95;...
    0.36, 0.33, 2.00, 1.09, 2.33]; %contact matrix retrieved from []
p = 0;%probability for wearing mask, sanitized hands, etc.
quar = 0.4*ones(NumStructur,1);
DeathRateTotal = 0.0012; %by fitting to SIRD model non age-structured
delta = DeathRateTotal*ones(NumStructur,1);
RecoveryRateTotal = 0.0354; %by fitting to SIRD model non age-structured 0.0359
gamma = (RecoveryRateTotal)*ones(NumStructur,1); %constant recovery assumption
v = 0*ones(NumStructur,1); %novaccine at first

%% Optimization
% selecting the initial guess
MaxIter = 1e3;
SobolBeta = sobolset(1,'Skip',1e3,'Leap',1e2); 
InitGuess = net(SobolBeta,MaxIter);
InitGuess(:,1) = 10*InitGuess(:,1);
InitGuess = InitGuess';
LowerBound = [0];
UpperBound = [10];

%first try
PropInfConnecticut = [0.0727; 0.1583; 2.0355; 0.8440; 1.9222]; %retrived from the connecticur data
I0 = (PropInfConnecticut./sum(PropInfConnecticut)).*19.5086; %estimation of the intitial condition
Q0 = (PropInfConnecticut./sum(PropInfConnecticut)).*ActiveCasesData(1);
R0 = (DATA(1,5)/NumStructur)*ones(NumStructur,1);
D0 = (DATA(1,6)/NumStructur)*ones(NumStructur,1);
Spop = [8660801; 8327843; 22865065; 5252107; 3916534];
S0 = Spop - Q0 - I0 - R0 - D0;
y0 = [S0;I0;Q0;R0;D0;R0;zeros(5,1)]; %initial conditions
tspan = 1:1:ts;
Min_ErrorGuess = CostRMSEFun(InitGuess(:,1),y0,v);
Min_InitGuess  = InitGuess(:,1);
%another try
for jj = 2 : MaxIter
    Temp_ErrorGuess = CostRMSEFun(InitGuess(:,jj),y0,v);
    Temp_InitGuess    = InitGuess(:,jj);
    if (Temp_ErrorGuess<Min_ErrorGuess)
        Min_InitGuess = Temp_InitGuess;
        Min_ErrorGuess = Temp_ErrorGuess;
    end    
end
%%
%invoke the optimization
[Min_Par,Min_Cost,residual,exitflag] = fmincon(@(x) CostRMSEFun(x,y0,v),Min_InitGuess,[],[],[],[],LowerBound,UpperBound);

%% plotting
close all;
tspan = 1:1:ts;
parbeta = Min_Par(1)*(beta_connecticut./sum(beta_connecticut));
[t,y] = ode45(@(t,y) Age5StructuredFun(t,y,parbeta,v),tspan, y0);
figure;
td  = datetime(2020,DATA(1,2),DATA(1,1)) + caldays(0:length(DATA)-1);
hold on
% p6=plot(td,CI1,'ro','MarkerSize',5)
p1=plot(td,y(:,11),'r-','LineWidth',2)

% plot(td,CI2,'mo','MarkerSize',5)
p2=plot(td,y(:,12),'m-','LineWidth',2)

% plot(td,CI3,'bo','MarkerSize',5)
p3=plot(td,y(:,13),'b-','LineWidth',2)

% plot(td,CI4,'co','MarkerSize',5)
p4=plot(td,y(:,14),'c-','LineWidth',2)

% plot(td,CI5,'ko','MarkerSize',5)
p5=plot(td,y(:,15),'k-','LineWidth',2)
hold off
grid on
grid minor
legend([p1,p2,p3,p4,p5],[{'Q1 (0-9)'},{'Q2 (10-19)'},{'Q3 (20-49)'},{'Q4 (50-59)'},{'Q5 (>60)'}],'location','northwest')
xlabel('Date')
ylabel('Number of Pople')
xlim([td(1),td(end)])
title('Active Cases of The Age-Structured Data: West Java')

% 
figure;
hold on
plot(td,y(:,11)+y(:,12)+y(:,13)+y(:,14)+y(:,15),'r-','LineWidth',2)
plot(td,ActiveCasesData,'ro','LineWidth',2)
plot(td,y(:,26)+y(:,27)+y(:,28)+y(:,29)+y(:,30),'g-','LineWidth',2)
plot(td,RecoveredData,'go','LineWidth',2)
plot(td,y(:,21)+y(:,22)+y(:,23)+y(:,24)+y(:,25),'k-','LineWidth',2)
plot(td,DeathData,'ko','LineWidth',2)
hold off
grid on
grid minor
legend('Q(t)','Active Cases','CR(t)','Total recovered','D(t)','Total death','location','northwest')
xlabel('Date')
ylabel('Number of Pople')
xlim([td(1),td(end)])
title('Tracking The Data')
% 
%% projection
v = [0;0;0;0;0];
t_proj = 1500;
tspan = 1 : 1: t_proj;
y0 = [S0;I0;Q0;R0;D0;R0;zeros(5,1)]; %initial conditions
[t,y] = ode45(@(t,y) Age5StructuredFun(t,y,parbeta,v),tspan, y0);
yp = y;
tdp  = datetime(2020,DATA(1,2),DATA(1,1)) + caldays(0:1500-1);
figure;
hold on
p1=plot(tdp,yp(:,11),'r-','LineWidth',2)
p2=plot(tdp,yp(:,12),'m-','LineWidth',2)
p3=plot(tdp,yp(:,13),'b-','LineWidth',2)
p4=plot(tdp,yp(:,14),'c-','LineWidth',2)
p5=plot(tdp,yp(:,15),'k-','LineWidth',2)
hold off
grid on
grid minor
xlim([tdp(1),tdp(end)])
ylim([0,1.2*max(yp(:,13))])
xlabel('DATE')
ylabel('NUMBER OF PEOPLE')
legend([p1,p2,p3,p4,p5],[{'Q1 (0-9)'},{'Q2 (10-19)'},{'Q3 (20-49)'},{'Q4 (50-59)'},{'Q5 (>60)'}],'location','northwest')
title('Projection of Age-Structured Active Cases: West Java')

%% vaccination
%% Vaksinasi Skenario 1
v = [0;0;0;0;0];
tspan1 = 1 : 1: ts;
NumPeriod = 12;
y0 = [S0;I0;Q0;R0;D0;R0;zeros(5,1)]; %initial conditions
[t,y] = ode45(@(t,y) Age5StructuredFun(t,y,parbeta,v),tspan1, y0);
yv1 = y; v = 0.001*ones(NumStructur,NumPeriod); %initial vaccine

figure
pcolor([v, zeros(size(v,1), 1); zeros(1, size(v,2)+1)]);
axis image
axis ij
colorbar
title('Vaccination Rate (1/day)')
xlabel('periode ke-')
ylabel('kelompok usia')

for i = 1 : NumPeriod
   tspansim = 1 : 31; %add 1 more
   y0 = yv1(end,:);
   [t,y] = ode45(@(t,y) Age5StructuredFun(t,y,parbeta,v(:,i)),tspansim, y0);
   yv1 = [yv1;y(2:end,:)];
end
figure;
hold on
tdv1  = datetime(2020,DATA(1,2),DATA(1,1)) + caldays(0:NumPeriod*30+ts-1);
plot(tdp,yp(:,11)+yp(:,12)+yp(:,13)+yp(:,14)+yp(:,15),'r-','LineWidth',2)
plot(tdv1,yv1(:,11)+yv1(:,12)+yv1(:,13)+yv1(:,14)+yv1(:,15),'r-.','LineWidth',2)
% plot(tdv1(1:ts),ActiveCasesData,'ro','LineWidth',2)
plot(tdp,yp(:,21)+yp(:,22)+yp(:,23)+yp(:,24)+yp(:,25),'k-','LineWidth',2)
plot(tdv1,yv1(:,21)+yv1(:,22)+yv1(:,23)+yv1(:,24)+yv1(:,25),'k-.','LineWidth',2)
% plot(tdp(1:ts),,'ko','LineWidth',2)
plot([tdv1(ts),tdv1(ts)],[0,1e9],'k--','LineWidth',1)
hold off
grid on
grid minor
xlim([tdv1(1),tdv1(end)])
legend('Active Cases (Without Vaccination)','Active Cases (With Vaccination)','Total Death (Without Vaccination)','Total Death (With Vaccination)','location','northeast')
xlabel('DATE')
ylabel('NUMBER OF PEOPLE')
ylim([0,1.2*max(yp(:,11)+yp(:,12)+yp(:,13)+yp(:,14)+yp(:,15))])
title('Projection of The Total Active Cases')






%% Supplementary Functions

%%
function dydt = Age5StructuredFun(t,y,beta,v)
global N contact NumStructur mu pi gamma delta quar zeta eta
dydt = zeros(NumStructur*7,1); % Si Ii Qi R D CIi
idx = 1;
    VirusTransmission = zeros(NumStructur,1); %ngitung sigma kontak dulu
    for j = 1 : NumStructur
        temp = 0;
        for i = 1 : NumStructur
            temp = temp + beta(j)*contact(j,i)*y(NumStructur+i);
        end
        VirusTransmission(j) = temp;
    end
    
for j = 1 : NumStructur %assigning the value of dS_i/dt
    dydt(idx) = pi(j)*(y(j)+y(NumStructur+j)+y(2*NumStructur+j)+y(3*NumStructur+j)) - y(j)*VirusTransmission(j)/(N) - mu(j)*y(j) - eta*v(j)*y(j) + zeta(j)*y(3*NumStructur+j);
    idx = idx+1;
end
for j = 1 : NumStructur %assigning the value of dI_i/dt
    dydt(idx) = y(j)*VirusTransmission(j)/(N) - (quar(j)+mu(j))*y(NumStructur+j);
    idx = idx+1;
end
for j = 1 : NumStructur %assigning the value of dQ_i/dt
    dydt(idx) = quar(j)*y(NumStructur+j) - (gamma(j)+delta(j)+mu(j))*y(2*NumStructur+j);
    idx = idx+1;
end
for j = 1 : NumStructur %assigning the value of dR_i/dt
    dydt(idx) = eta*v(j)*y(j) + gamma(j)*y(2*NumStructur+j) - (mu(j)+zeta(j))*y(3*NumStructur+j);
    idx = idx+1;
end
for j = 1 : NumStructur %assigning the value of dD_i/dt
    dydt(idx) = delta(j)*y(2*NumStructur+j);
    idx = idx+1;
end
for j = 1 : NumStructur %assigning the value of dCR_i/dt
    dydt(idx) = gamma(j)*y(2*NumStructur+j);
    idx = idx+1;
end
for j = 1 : NumStructur %assigning the value of V
    dydt(idx) = v(j)*y(j);
    idx = idx+1;
end

end


%% 
function error = CostRMSEFun(x,y0,v)
    % This code evaluates the RMSE of the data and the model
    global ts beta_connecticut ActiveCasesData RecoveredData DeathData
    tspan=1:1:ts;
    beta = x(1)*(beta_connecticut./sum(beta_connecticut));
    [t,y] = ode45(@(t,y) Age5StructuredFun(t,y,beta,v), tspan, y0);
    % define the RMSE
    AC_def = y(:,11)+y(:,12)+y(:,13)+y(:,14)+y(:,15);
    CR_def = y(:,26)+y(:,27)+y(:,28)+y(:,29)+y(:,30);
    CD_def = y(:,21)+y(:,22)+y(:,23)+y(:,24)+y(:,25);
    error = sqrt(sum(abs(ActiveCasesData-AC_def)));
%     if (max(beta) > 1)
%         error = 1e100;
%     end
end
