% BISMILLAHIRRAHMAANIRRAHIIM
% This code provides the estimation f the constant parameters of the SIQRD
% model. We use the least square method to minimize the RMSE of the data
% and the model.
% INPUT : DATA (Active cases, cumulative recovered, cumulative death)
% OUTPUT: estimated beta, gamma, delta and q

%% ------------------------------------------------------------------------
% This code begins here
% -------------------------------------------------------------------------
clear all
clc
close all
global AC CR N v ts mu CD quar zeta eta p

%% Input Data
DATA = load('Data/Jawa Barat.txt');
AC = DATA(:,4); % active cases
CR = DATA(:,5); % recovered
CD = DATA(:,6); % deaths
N = sum(DATA(1,3:6)); % population
v = 0; %no vaccine at first
ts = length(DATA); %simulation time
mu = 1/(70*365); %death and birth rate of human
quar = 0.4;
zeta = 1/((5/12)*365);
eta = 0.8;
p = 0.3;

%% Selecting the initial guess of the opt. function
MaxIter = 1e3;
NumberParameter = 4;
Q0 = sobolset(NumberParameter,'Skip',1e3,'Leap',1e2); 
InitGuess = net(Q0,MaxIter); %tebakan awal sebanyak m buah, size=(m,3)
InitGuess(:,1) = 3*InitGuess(:,1); %multiplying beta by 3, as it can be as large as 3.
InitGuess(:,4) = 100*InitGuess(:,4); %multiplying I(0) by 100, as it can be as large as 100
LowerBound=[0,0,0,0]; 
UpperBound=[3,1,1,Inf]; 
% first try
Min_ErrorGuess = cost_function(InitGuess(1,:));
Min_InitGuess    = InitGuess(1,:);
%another try
for i = 2 : MaxIter
    Temp_ErrorGuess = cost_function(InitGuess(i,:));
    Temp_InitGuess    = InitGuess(i,:);
    if (Temp_ErrorGuess<Min_ErrorGuess)
        Min_InitGuess = Temp_InitGuess;
        Min_ErrorGuess = Temp_ErrorGuess;
    end
end

%% Optimization using fmincon
[Min_Par,Min_Cost,residual,exitflag] = fmincon(@cost_function,Min_InitGuess,[],[],[],[],LowerBound,UpperBound)

%% Simulation and plotting
close all
tspan=1:1:1500;
y0 = [N-Min_Par(4)-AC(1)-CR(1)-CD(1),Min_Par(4), AC(1), CR(1), CD(1), CR(1)]; %initial condition of the system
[t,y] = ode45(@(t,y) system_function(t,y,Min_Par(1),Min_Par(2),Min_Par(3)), tspan, y0);
td = datetime(2020,DATA(1,2),DATA(1,1)) + caldays(0:length(tspan)-1);
hold on
plot(td(1:ts),AC,'ro')
plot(td(1:ts),y(1:ts,3),'r','LineWidth',2)
plot(td(1:ts),CR,'go')
plot(td(1:ts),y(1:ts,6),'g','LineWidth',2)
plot(td(1:ts),CD,'ko')
plot(td(1:ts),y(1:ts,5),'K','LineWidth',2)
% plot(td(1:ts),y(1:ts,1),'m','LineWidth',1.5)
% plot(y(:,2),'m','LineWidth',1.5)
hold off
xlabel('date')
ylabel('number of people')
grid on
grid minor
xlim([td(1),td(ts)])
title('Tracking data: West Java')
legend('Active cases','I(t)','cumulative recovered','CR(t)','cumulative death','D(t)','location','northwest')
filename='Figures/FigTrackingWestJava.png';
saveas(gcf,filename)

figure; %simulation until the last data
hold on
% plot(td(1:ts),AC,'ro')
plot(td(1:end),y(:,3),'r','LineWidth',2)
% plot(td(1:ts),CR,'go')
plot(td(1:end),y(:,4),'g','LineWidth',2)
% plot(td(1:ts),CD,'ko')
plot(td(1:end),y(:,5),'k','LineWidth',2)
% plot(y(:,2),'m','LineWidth',1.5)
hold off
xlabel('date')
ylabel('number of people')
xlim([td(1),td(length(tspan))])
grid on
grid minor
title('Prediction: West Java')
legend('Active Cases','Total immune','Total Death','location','northwest')
filename='Figures/FigTrackingExtendedWestJava.png';
saveas(gcf,filename)
% This code ends here
%%-------------------------------------------------------------------------
% Supplementary Functions
% -------------------------------------------------------------------------
function dydt = system_function(t,y,beta, gamma,delta)
% this function defines the mathematical model of SIQRD
global N v mu quar zeta eta p
dydt = zeros(6,1);
dydt(1) = mu*(y(1)+y(2)+y(3)+y(4)) - (1-p)*beta*(y(1)*y(2))/N - eta*v*y(1) - mu*y(1) + zeta*y(4);
dydt(2) = (1-p)*beta*(y(1)*y(2))/N - quar*y(2) - mu*y(2);
dydt(3) = quar*y(2) - (gamma + delta)*y(3)-mu*y(3) ;
dydt(4) = gamma*y(3) + eta*v*y(1)-mu*y(4) - zeta*y(4);
dydt(5) = delta*y(3);
dydt(6) = gamma*y(3);
end

function error = cost_function(x)
% This code evaluates the RMSE of the data and the model
global AC CR ts CD N 
tspan=1:1:ts;
y0 = [N-x(4)-AC(1)-CR(1)-CD(1),x(4), AC(1), CR(1), CD(1),CR(1)]; %initial condition of the system
[t,y] = ode45(@(t,y) system_function(t,y,x(1),x(2),x(3)), tspan, y0);
error = (sqrt(sum((AC-y(:,3)).^2)) + sqrt(sum((CR-y(:,6)).^2)) + sqrt(sum((CD-y(:,5)).^2)) )/length(AC); %RMSE
end