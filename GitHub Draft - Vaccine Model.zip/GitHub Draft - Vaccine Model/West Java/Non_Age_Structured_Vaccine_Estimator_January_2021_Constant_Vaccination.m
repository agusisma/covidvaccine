% This code provides the simulation of constant vaccination


%% ------------------------------------------------------------------------
% Main code begins here

clear all;
clc
close all
global N beta gamma quar mu delta zeta eta

%previous results
eta = 0.8;
beta = 0.4212;
gamma = 0.0354;
delta = 0.0012;
quar = 0.4000;
I0 = 19.5086;
zeta = 1/((5/12)*365);
%% Input Data
DATA = load('Data/Jawa Barat.txt');
AC = DATA(:,4);
CR = DATA(:,5);
CD = DATA(:,6);
N = sum(DATA(1,3:6));
v = 0; %no vaccine at first
ts = length(DATA)+74;
td = datetime(2020,DATA(1,2),DATA(1,1))+caldays(0:ts-1);
mu = 1/(70*365); %death and birth rate of human

%% hyperparameters
VaccPeriod = 12; %months
MaxHealthCare = 11e4; % person


%% Vaccination estimation
% before vacccination
tspan=1:1:ts;
y0 = [N-I0-AC(1)-CR(1)-CD(1), I0, AC(1), CR(1), CD(1), CR(1), 0]; %initial condition of the system
[t,y] = ode45(@(t,y) system_function(t,y,0), tspan, y0);
S = y(:,1); I = y(:,2); Q = y(:,3); R = y(:,4); D = y(:,5); CR = y(:,6); V = y(:,7);%assigning the simulation result to variable SIRD
yInit = [S, I, Q, R, D, CR, V];

% Selecting the Initial Guess of the optimization process
MaxIter = 1e3;
Q0 = sobolset(VaccPeriod,'Skip',1e3,'Leap',1e2);
InitGuess = (1/(VaccPeriod*30))*net(Q0,MaxIter); %tebakan awal sebanyak m buah, size=(m,3)
InitGuess = (50000/N)*rand(MaxIter,12);
LowerBound=zeros(VaccPeriod,1); % lower bound
UpperBound=(50000/N)*ones(VaccPeriod,1); % upper limit
% first try
Min_GuessCost = cost_function(InitGuess(1,:),S,I,Q,R,D,CR,V,VaccPeriod,MaxHealthCare);
Min_InitGuess = InitGuess(1,:);
%another try
for j = 2 : MaxIter
    Temp_InitGuess = InitGuess(j,:);
    Temp_Cost = cost_function(Temp_InitGuess,S,I,Q,R,D,CR,V,VaccPeriod,MaxHealthCare);
    if (Temp_Cost < Min_GuessCost)
        Min_GuessCost = Temp_Cost;
        Min_InitGuess = Temp_InitGuess;
    end
end

% Optimization
[Min_Vaccine,Cost_Vaccine,exitflag] = fmincon(@(v) cost_function(v,S,I,Q,R,D,CR,V,VaccPeriod,MaxHealthCare),...
    Min_InitGuess, [], [], [], [], LowerBound, UpperBound);
% Min_Vaccine = Min_InitGuess;
% After vaccination and conducted consistently
%% OPTIMAL
Ext = 0;
tspan_Periodically = 1:1:31; % monthly (30 days)
%modifying the vaccine rate to see how is it gonna be if the vaccine is not
%consistently conducted
% Min_Vaccine(2:end) = zeros(1,11);
Min_Vaccine = [Min_Vaccine, zeros(1,Ext)]

for jj = 1 : VaccPeriod+Ext
        y0 = [N-I(end)-R(end)-Q(end)-D(end),I(end),Q(end),R(end),D(end),CR(end),V(end)]; % initial condition
        [t,y] = ode45(@(t,y) system_function(t,y,Min_Vaccine(jj)), tspan_Periodically, y0);
        S = [S;y(2:end,1)]; 
        I = [I;y(2:end,2)]; 
        Q = [Q;y(2:end,3)]; 
        R = [R;y(2:end,4)];
        D = [D;y(2:end,5)];
        CR = [CR;y(2:end,6)];
        V = [V;y(2:end,7)]; 
end


%% MEAN
Min_Vaccine_Mean = mean(Min_Vaccine)*ones(1,length(Min_Vaccine));
Ext = 0;
tspan_Periodically = 1:1:31; % monthly (30 days)
%modifying the vaccine rate to see how is it gonna be if the vaccine is not
%consistently conducted
% Min_Vaccine(2:end) = zeros(1,11);
Min_Vaccine_Mean = [Min_Vaccine_Mean, zeros(1,Ext)];
Sc = yInit(:,1); Ic = yInit(:,2); Qc = yInit(:,3); Rc = yInit(:,4); Dc = yInit(:,5); CRc = yInit(:,6); Vc = yInit(:,7);
for jj = 1 : VaccPeriod+Ext
        y0 = [N-Ic(end)-Rc(end)-Qc(end)-Dc(end),Ic(end),Qc(end),Rc(end),Dc(end),CRc(end),Vc(end)]; % initial condition
        [t,y] = ode45(@(t,y) system_function(t,y,Min_Vaccine_Mean(jj)), tspan_Periodically, y0);
        Sc = [Sc;y(2:end,1)]; 
        Ic = [Ic;y(2:end,2)]; 
        Qc = [Qc;y(2:end,3)]; 
        Rc = [Rc;y(2:end,4)];
        Dc = [Dc;y(2:end,5)];
        CRc = [CRc;y(2:end,6)];
        Vc = [Vc;y(2:end,7)]; 
end

%% MAXIMUM
Min_Vaccine_Max = max(Min_Vaccine)*ones(1,length(Min_Vaccine));
Ext = 0;
tspan_Periodically = 1:1:31; % monthly (30 days)
%modifying the vaccine rate to see how is it gonna be if the vaccine is not
%consistently conducted
% Min_Vaccine(2:end) = zeros(1,11);
Min_Vaccine_Max = [Min_Vaccine_Max, zeros(1,Ext)];
Smax = yInit(:,1); Imax = yInit(:,2); Qmax = yInit(:,3); Rmax = yInit(:,4); Dmax = yInit(:,5); CRmax = yInit(:,6); Vmax = yInit(:,7);
for jj = 1 : VaccPeriod+Ext
        y0 = [N-Imax(end)-Rmax(end)-Qmax(end)-Dmax(end),Imax(end),Qmax(end),Rmax(end),Dmax(end),CRmax(end),Vmax(end)]; % initial condition
        [t,y] = ode45(@(t,y) system_function(t,y,Min_Vaccine_Max(jj)), tspan_Periodically, y0);
        Smax = [Smax;y(2:end,1)]; 
        Imax = [Imax;y(2:end,2)]; 
        Qmax = [Qmax;y(2:end,3)]; 
        Rmax = [Rmax;y(2:end,4)];
        Dmax = [Dmax;y(2:end,5)];
        CRmax = [CRmax;y(2:end,6)];
        Vmax = [Vmax;y(2:end,7)]; 
end

%% MINIMUM
Min_Vaccine_Min = min(Min_Vaccine)*ones(1,length(Min_Vaccine));
Ext = 0;
tspan_Periodically = 1:1:31; % monthly (30 days)
%modifying the vaccine rate to see how is it gonna be if the vaccine is not
%consistently conducted
% Min_Vaccine(2:end) = zeros(1,11);
Min_Vaccine_Min = [Min_Vaccine_Min, zeros(1,Ext)];
Smin = yInit(:,1); Imin = yInit(:,2); Qmin = yInit(:,3); Rmin = yInit(:,4); Dmin = yInit(:,5); CRmin = yInit(:,6); Vmin = yInit(:,7);
for jj = 1 : VaccPeriod+Ext
        y0 = [N-Imin(end)-Rmin(end)-Qmin(end)-Dmin(end),Imin(end),Qmin(end),Rmin(end),Dmin(end),CRmin(end),Vmin(end)]; % initial condition
        [t,y] = ode45(@(t,y) system_function(t,y,Min_Vaccine_Min(jj)), tspan_Periodically, y0);
        Smin = [Smin;y(2:end,1)]; 
        Imin = [Imin;y(2:end,2)]; 
        Qmin = [Qmin;y(2:end,3)]; 
        Rmin = [Rmin;y(2:end,4)];
        Dmin = [Dmin;y(2:end,5)];
        CRmin = [CRmin;y(2:end,6)];
        Vmin = [Vmin;y(2:end,7)]; 
end





% without vaccination as the comparison
close all;
tspan=1:1:ts+(VaccPeriod+Ext)*30;
y0 = [N-I0-AC(1)-CR(1)-CD(1), I0, AC(1), CR(1), CD(1), CR(1), 0]; %initial condition of the system
[t,y] = ode45(@(t,y) system_function(t,y,0), tspan, y0);
St = y(:,1); It = y(:,2); Qt = y(:,3); Rt = y(:,4); Dt = y(:,5); CRt = y(:,6); Vt = y(:,7);%assigning the simulation result to variable SIRD

% Plotting
td = datetime(2020,DATA(1,2),DATA(1,1))+caldays(0:ts+(VaccPeriod+Ext)*30-1); %date array
% td1 = datetime(2020,DATA(1,2),DATA(1,1))+caldays(0:1500-1); %date array
figure
hold on
% without vaccination

plot(td,Q,'b','LineWidth',2)
plot(td,Qc,'b-.','LineWidth',2)
plot(td,Qmax,'b--','LineWidth',2)
plot(td,Qmin,'b--','LineWidth',2)
plot(td,Qt,'r','LineWidth',2)
plot(td,MaxHealthCare*ones(1,ts+(VaccPeriod+Ext)*30),'g-','LineWidth',2)
plot([td(ts),td(ts)],[0,1e9],'k','LineWidth',2)
hold off
grid on
grid minor
xlabel('DATE (days)')
ylabel('CASES (person)')
xlim([td(1),td(end)])
ylim([0,1.2*max(max(Q),max(Qt))])
t = text(td(ts)-25,3e4,[{'Vaccination starts on'};datestr(td(ts))])
t.Rotation = 90;
legend('Optimal vaccine','Average vaccine','Max vaccine','Min vaccine','Without vaccine','location','northwest')
% saving figure
% filename = 'Figures\FigVaccineEffect.png';
% saveas(gcf,filename)



Vk = [];
Qk = [];
Vkmean = [];
Qkmean = [];
Vkmax = [];
Qkmax = [];
Vkmin = [];
Qkmin = [];
for i = 1 : 12
    Vk = [Vk; V(ts+30*i)];
    Qk = [Qk; Q(ts+30*i)];
    Vkmean = [Vkmean; Vc(ts+30*i)];
    Qkmean = [Qkmean; Qc(ts+30*i)];
    Vkmax = [Vkmax; Vmax(ts+30*i)];
    Qkmax = [Qkmax; Qmax(ts+30*i)];
    Vkmin = [Vkmin; Vmin(ts+30*i)];
    Qkmin = [Qkmin; Qmin(ts+30*i)];
end
Persen = (Vk./N)*100;
VaccineScene = [Vk(1);diff(Vk)]./30;
Persenmean = (Vkmean./N)*100;
VaccineScenemean = [Vkmean(1);diff(Vkmean)]./30;
Persenmax = (Vkmax./N)*100;
VaccineScenemax = [Vkmax(1);diff(Vkmax)]./30;
Persenmin = (Vkmin./N)*100;
VaccineScenemin = [Vkmin(1);diff(Vkmin)]./30;

figure;
yyaxis left
hold on
Min_VaccineArray = zeros(ts,1);
Min_Vaccine_ConArray = zeros(ts,1);
Min_Vaccine_MaxArray = zeros(ts,1);
Min_Vaccine_MinArray = zeros(ts,1);
for j = 1 : VaccPeriod
    Min_VaccineArray = [Min_VaccineArray; VaccineScene(j)*ones(30,1)];
    Min_Vaccine_ConArray = [Min_Vaccine_ConArray; VaccineScenemean(j)*ones(30,1)];
    Min_Vaccine_MaxArray = [Min_Vaccine_MaxArray; VaccineScenemax(j)*ones(30,1)];
    Min_Vaccine_MinArray = [Min_Vaccine_MinArray; VaccineScenemin(j)*ones(30,1)];
end
Min_VaccineArray = [Min_VaccineArray; zeros(Ext*30,1)];
Min_Vaccine_ConArray = [Min_Vaccine_ConArray; zeros(Ext*30,1)];
Min_Vaccine_MaxArray = [Min_Vaccine_MaxArray; zeros(Ext*30,1)];
Min_Vaccine_MinArray = [Min_Vaccine_MinArray; zeros(Ext*30,1)];
plot(td,Min_VaccineArray,'b*','MarkerSize',5)
plot(td,Min_Vaccine_ConArray,'m*','MarkerSize',5)
plot(td,Min_Vaccine_MaxArray,'mo','MarkerSize',5)
plot(td,Min_Vaccine_MinArray,'mo','MarkerSize',5)
hold off
ylim([0,1.2*max(Min_VaccineArray)])
ylabel('#VACCINE (people/day)')

yyaxis right
plot(td,S,'LineWidth',2)
grid on
grid minor
xlim([td(1),td(end)])
ylabel('SUSCEPTIBLE (person)')

% saving figure
% filename = 'Figures\FigVaccineRateandSusceptible.png';
% saveas(gcf,filename)

% %% What if the vaccine is not consistently conducted?
% % before vaccinaction
% tspan=1:1:ts;
% y0 = [N-I(end)-R(end)-Q(end)-D(end),I(end),Q(end),R(end),D(end),CR(end),V(end)]; %initial condition of the system
% [t,y] = ode45(@(t,y) system_function(t,y,0), tspan, y0);
% Svt = y(:,1); Ivt = y(:,2); Qvt = y(:,3); Rvt = y(:,4); Dvt = y(:,5); CRvt = y(:,6); Vvt = y(:,7);%assigning the simulation result to variable SIRD
% 
% % after vaccination and only for 2 months
% tspan_Periodically = 1:1:30; % monthly (30 days)
% %modifying the vaccine rate to see how is it gonna be if the vaccine is not
% %consistently conducted
% Min_Vaccine_Not_Consistent = [Min_Vaccine(1),zeros(1,11)]; %1 month vaccination only
% for jj = 1 : VaccPeriod
%         y0 = [N-Ivt(end)-Rvt(end)-Qvt(end)-Dvt(end),Ivt(end),Qvt(end),Rvt(end),Dvt(end),CRvt(end),Vvt(end)]; % initial condition
%         [t,y] = ode45(@(t,y) system_function(t,y,Min_Vaccine_Not_Consistent(jj)), tspan_Periodically, y0);
%         Svt = [Svt;y(:,1)]; 
%         Ivt = [Ivt;y(:,2)]; 
%         Qvt = [Qvt;y(:,3)]; 
%         Rvt = [Rvt;y(:,4)]; 
%         Dvt = [Dvt;y(:,3)]; 
%         CRvt = [CRvt;y(:,3)]; 
%         Vvt = [Vvt;y(:,5)]; 
% end
% 
% % Plotting
% figure;
% td = datetime(2020,DATA(1,2),DATA(1,1))+caldays(0:ts+VaccPeriod*30-1); %date array
% hold on
% % without vaccination
% plot(td,Qt,'r','LineWidth',2)
% % with vaccination
% plot(td,Qvt,'r-.','LineWidth',2)
% plot(td,Q,'r:','LineWidth',2)
% plot([td(ts),td(ts)],[0,1e9],'k','LineWidth',2)
% plot(td,MaxHealthCare*ones(1,ts+VaccPeriod*30),'g-','LineWidth',2)
% hold off
% grid on
% grid minor
% xlabel('DATE (days)')
% ylabel('CASES (person)')
% xlim([td(1),td(end)])
% ylim([0,1.2*max(max(Q),max(Qt))])
% legend('Without Vaccination','With Unconsistent Vaccination','With Consistent Vaccination','Beginning of Vaccination','Maximum Healthcare Capacity','location','northwest')
% % saving figure
% filename = 'Figures\FigVaccineUnconcistentEffect.png';
% saveas(gcf,filename)
% 
% 
% %% What if the vaccine is not on-off
% figure;
% % before vaccinaction
% tspan=1:1:ts;
% y0 = [N--AC(1)-AC(1)-CR(1),AC(1), AC(1), CR(1),0]; %initial condition of the system
% [t,y] = ode45(@(t,y) system_function(t,y,0), tspan, y0);
% Svoft = y(:,1); Ivoft = y(:,2); Qvoft = y(:,3); Rvoft = y(:,4); Vvoft = y(:,5); %assigning the simulation result to variable SIRD
% 
% % after vaccination and only for 2 months
% tspan_Periodically = 1:1:30; % monthly (30 days)
% %modifying the vaccine rate to see how is it gonna be if the vaccine is not
% %consistently conducted
% Min_Vaccine_On_Off = Min_Vaccine;
% Min_Vaccine_On_Off(2) = 0;
% Min_Vaccine_On_Off(4) = 0;
% Min_Vaccine_On_Off(6) = 0;
% Min_Vaccine_On_Off(8) = 0;
% Min_Vaccine_On_Off(10) = 0;
% Min_Vaccine_On_Off(12) = 0;
% for jj = 1 : VaccPeriod
%         y0 = [N-Ivoft(end)-Rvoft(end)-Qvoft(end),Ivoft(end),Qvoft(end),Rvoft(end),Vvoft(end)]; % initial condition
%         [t,y] = ode45(@(t,y) system_function(t,y,Min_Vaccine_On_Off(jj)), tspan_Periodically, y0);
%         Svoft = [Svoft;y(:,1)]; 
%         Ivoft = [Ivoft;y(:,2)]; 
%         Qvoft = [Qvoft;y(:,3)]; 
%         Rvoft = [Rvoft;y(:,4)]; 
%         Vvoft = [Vvoft;y(:,5)]; 
% end
% 
% % Plotting
% td = datetime(2020,DATA(1,2),DATA(1,1))+caldays(0:ts+VaccPeriod*30-1); %date array
% hold on
% % without vaccination
% plot(td,Qt,'r','LineWidth',2)
% % with vaccination
% plot(td,Qvoft,'r--','LineWidth',2)
% plot(td,Qvt,'r-.','LineWidth',2)
% plot(td,Q,'r:','LineWidth',2)
% plot([td(ts),td(ts)],[0,1e9],'k','LineWidth',2)
% plot(td,MaxHealthCare*ones(1,ts+VaccPeriod*30),'g-','LineWidth',2)
% hold off
% grid on
% grid minor
% xlabel('DATE (days)')
% ylabel('CASES (person)')
% xlim([td(1),td(end)])
% ylim([0,1.2*max(max(Q),max(Qt))])
% legend('Without Vaccination','With On-Off Vaccination','With 1-Month Vaccination','With Consistent Vaccination','Beginning of Vaccination','Maximum Healthcare Capacity','location','northwest')
% % saving figure
% filename = 'Figures\FigVaccineOnOffEffect.png';
% saveas(gcf,filename)
% 

%%
Vk = [];
Qk = [];
for i = 1 : 12
    Vk = [Vk; V(ts+30*i)];
    Qk = [Qk; Q(ts+30*i)];
end
Persen = (Vk./N)*100;

% Main code ends here
%% --------------------------------------------------------------
% Supplementary Functions
% ---------------------------------------------------------------

function dydt = system_function(t,y,v)
% this function defines the mathematical model of SIQRD
global N mu quar zeta beta gamma delta eta
dydt = zeros(7,1);
dydt(1) = mu*(y(1)+y(2)+y(3)+y(4)) - beta*(y(1)*y(2))/N - eta*v*y(1) - mu*y(1) + zeta*y(4);
dydt(2) = beta*(y(1)*y(2))/N - quar*y(2) - mu*y(2);
dydt(3) = quar*y(2) - (gamma + delta)*y(3)-mu*y(3) ;
dydt(4) = gamma*y(3) + eta*v*y(1)-mu*y(4) - zeta*y(4);
dydt(5) = delta*y(3);
dydt(6) = gamma*y(3);
dydt(7) = v*y(1);
end

function VaccineTotalCost = cost_function(v,S,I,Q,R,D,CR,V,VaccPeriod,MaxHealthCare)
% This function evaluates the cost function
    global N
    VaccinePrice = 1; % this is assumed
    VaccineTotalPeople = 0; % number of people getting vaccinated on peroid-i
    VaccineTotalPeople_prev = 0; % number of people getting vaccinated on peroid-(i-1). ...
    %This is defined since we have cummulative vaccinated people. So, to
    %calculate #vaccinated person in period i, we simply can calculate the
    %difference.
    tspan = 1:1:31;
    for j = 1 : VaccPeriod
        y0 = [N-I(end)-R(end)-Q(end)-D(end),I(end),Q(end),R(end),D(end),CR(end),V(end)]; %simulation
        [t,y] = ode45(@(t,y) system_function(t,y,v(j)), tspan, y0);
        S = [S;y(2:end,1)]; 
        I = [I;y(2:end,2)]; 
        Q = [Q;y(2:end,3)]; 
        R = [R;y(2:end,4)]; 
        D = [D;y(2:end,5)];
        CR = [CR;y(2:end,6)];
        V = [V;y(2:end,7)];
        VaccineTotalPeople = VaccineTotalPeople + V(end) - VaccineTotalPeople_prev; %calculating the vaccinated person
        VaccineTotalPeople_prev = V(end);
    end
    if (max(Q) >= MaxHealthCare) || (I(end)>1)%omitting the unfeasible solution
        VaccineTotalCost = 1e100; % by making the VaccineTotalCost as large as possible
    else
        VaccineTotalCost = VaccinePrice*VaccineTotalPeople;
    end
   
end