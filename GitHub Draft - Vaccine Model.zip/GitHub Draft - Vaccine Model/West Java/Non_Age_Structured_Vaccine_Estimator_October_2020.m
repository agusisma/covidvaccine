% This code provides the optimization of vaccine schedule to minimize the
% operational cost, and definitely keep supressing the number of active
% cases (SCENARIO 1: VACCINE IN OCTOBER 2020)
% INPUT : constant parameter of SIQRD model (beta, gamma, delta, q),
% Time-series DATA (Active cases, cummulative recovered, cummulative
% death), VaccPeriod (how long, in month, the vaccine will be implemented),
% MaxHealthCare (in person), 
% OUTPUT : opmtimized vaccination rate, Min_Vaccine, in (1/day) unit.


%% ------------------------------------------------------------------------
% Main code begins here

clear all;
clc
close all
global N beta gamma quar mu delta zeta eta

% Results (beta, gamma, delta, I0) from Non_Age_Structured_Data_Fitting.m
eta = 0.8;
beta = 0.4212;
gamma = 0.0354;
delta = 0.0012;
quar = 0.4000;
I0 = 19.5086;
zeta = 1/((5/12)*365);
%% Input Data
DATA = load('Data/Jawa Barat.txt');
AC = DATA(:,4);
CR = DATA(:,5);
CD = DATA(:,6);
N = sum(DATA(1,3:6));
v = 0; %no vaccine at first
ts = length(DATA);
td = datetime(2020,DATA(1,2),DATA(1,1))+caldays(0:ts-1);
mu = 1/(70*365); %death and birth rate of human

%% hyperparameters
VaccPeriod = 12; %months
MaxHealthCare = 5e4; % person


%% Vaccination estimation
% before vacccination
tspan=1:1:ts;
y0 = [N-I0-AC(1)-CR(1)-CD(1), I0, AC(1), CR(1), CD(1), CR(1), 0]; %initial condition of the system
[t,y] = ode45(@(t,y) system_function(t,y,0), tspan, y0);
S = y(:,1); I = y(:,2); Q = y(:,3); R = y(:,4); D = y(:,5); CR = y(:,6); V = y(:,7);%assigning the simulation result to variable SIRD


% Selecting the Initial Guess of the optimization process
MaxIter = 1e3;
Q0 = sobolset(VaccPeriod,'Skip',1e3,'Leap',1e2);
InitGuess = (100000/N)*net(Q0,MaxIter); %tebakan awal sebanyak m buah, size=(m,3)
InitGuess = (100000/N)*rand(MaxIter,12);
LowerBound=zeros(VaccPeriod,1); % lower bound
UpperBound=(100000/N)*ones(VaccPeriod,1); % upper limit
% first try
Min_GuessCost = cost_function(InitGuess(1,:),S,I,Q,R,D,CR,V,VaccPeriod,MaxHealthCare);
Min_InitGuess = InitGuess(1,:);
%another try
for j = 2 : MaxIter
    Temp_InitGuess = InitGuess(j,:);
    Temp_Cost = cost_function(Temp_InitGuess,S,I,Q,R,D,CR,V,VaccPeriod,MaxHealthCare);
    if (Temp_Cost < Min_GuessCost)
        Min_GuessCost = Temp_Cost;
        Min_InitGuess = Temp_InitGuess;
    end
end

% Optimization
[Min_Vaccine,Cost_Vaccine,exitflag] = fmincon(@(v) cost_function(v,S,I,Q,R,D,CR,V,VaccPeriod,MaxHealthCare),...
    Min_InitGuess, [], [], [], [], LowerBound, UpperBound);

%%
% Min_Vaccine = Min_InitGuess;
% after vaccination and conducted consistently
tspan_Periodically = 1:1:31; % monthly (30 days)
Ext = 0; 
%modifying the vaccine rate to see how is it gonna be if the vaccine is not
%consistently conducted
% Min_Vaccine(3:end) = zeros(1,10);\
Min_Vaccine = [Min_Vaccine, zeros(1,Ext)]
for jj = 1 : VaccPeriod+Ext
        y0 = [N-I(end)-R(end)-Q(end)-D(end),I(end),Q(end),R(end),D(end),CR(end),V(end)]; % initial condition
        [t,y] = ode45(@(t,y) system_function(t,y,Min_Vaccine(jj)), tspan_Periodically, y0);
        S = [S;y(2:end,1)]; 
        I = [I;y(2:end,2)]; 
        Q = [Q;y(2:end,3)]; 
        R = [R;y(2:end,4)];
        D = [D;y(2:end,5)];
        CR = [CR;y(2:end,6)];
        V = [V;y(2:end,7)]; 
end

%% without vaccination as the comparison
close all;
tspan=1:1:ts+(VaccPeriod+Ext)*30;
y0 = [N-I0-AC(1)-CR(1)-CD(1), I0, AC(1), CR(1), CD(1), CR(1), 0]; %initial condition of the system
[t,y] = ode45(@(t,y) system_function(t,y,0), tspan, y0);
St = y(:,1); It = y(:,2); Qt = y(:,3); Rt = y(:,4); Dt = y(:,5); CRt = y(:,6); Vt = y(:,7);%assigning the simulation result to variable SIRD

% Plotting
td = datetime(2020,DATA(1,2),DATA(1,1))+caldays(0:ts+(VaccPeriod+Ext)*30-1); %date array
% td1 = datetime(2020,DATA(1,2),DATA(1,1))+caldays(0:1500-1); %date array
figure
hold on
% without vaccination
plot(td,Qt,'r','LineWidth',2)
plot(td,Dt,'k','LineWidth',2)
% with vaccination
plot(td,Q,'r-.','LineWidth',2)
plot(td,D,'k-.','LineWidth',2)
plot(td,MaxHealthCare*ones(1,ts+(VaccPeriod+Ext)*30),'g-','LineWidth',2)
plot([td(ts),td(ts)],[0,1e9],'k','LineWidth',2)
hold off
grid on
grid minor
xlabel('DATE (days)')
ylabel('CASES (person)')
xlim([td(1),td(end)])
ylim([0,1.2*max(max(Q),max(Qt))])
t = text(td(ts)-25,3e4,[{'Vaccination starts on'};datestr(td(ts))])
t.Rotation = 90;
legend('Q(t) (No Vaccine)','D(t) (No Vaccine)','Q(t) (With Vaccine)','D(t) (With Vaccine)','Max. healthcare','location','northwest')
% saving figure
filename = 'Figures\FigVaccineEffect.png';

Vk = [];
Qk = [];
for i = 1 : 12
    Vk = [Vk; V(ts+30*i)];
    Qk = [Qk; Q(ts+30*i)];
end
Persen = (Vk./N)*100;
VaccineScene = [Vk(1);diff(Vk)]./30;

figure;
yyaxis left
hold on
Min_VaccineArray = zeros(ts,1);
for j = 1 : VaccPeriod
    Min_VaccineArray = [Min_VaccineArray; VaccineScene(j)*ones(30,1)];
end
Min_VaccineArray = [Min_VaccineArray; zeros(30*Ext,1)];
plot(td,Min_VaccineArray,'b*','MarkerSize',5)
hold off
ylim([0,1.2*max(Min_VaccineArray)])
ylabel('#VACCINE (people/day)')

yyaxis right
plot(td,S,'LineWidth',2)
grid on
grid minor
xlim([td(1),td(end)])
ylabel('SUSCEPTIBLE (person)')

% saving figure
filename = 'Figures\FigVaccineRateandSusceptible.png';

%%
Vk = [];
Qk = [];
for i = 1 : 12
    Vk = [Vk; V(ts+30*i)];
    Qk = [Qk; Q(ts+30*i)];
end
Persen = (Vk./N)*100;

% Main code ends here
%% --------------------------------------------------------------
% Supplementary Functions
% ---------------------------------------------------------------

function dydt = system_function(t,y,v)
% this function defines the mathematical model of SIQRD
global N mu quar zeta beta gamma delta eta
dydt = zeros(7,1);
dydt(1) = mu*(y(1)+y(2)+y(3)+y(4)) - beta*(y(1)*y(2))/N - eta*v*y(1) - mu*y(1) + zeta*y(4);
dydt(2) = beta*(y(1)*y(2))/N - quar*y(2) - mu*y(2);
dydt(3) = quar*y(2) - (gamma + delta)*y(3)-mu*y(3) ;
dydt(4) = gamma*y(3) + eta*v*y(1)-mu*y(4) - zeta*y(4);
dydt(5) = delta*y(3);
dydt(6) = gamma*y(3);
dydt(7) = v*y(1);
end

function VaccineTotalCost = cost_function(v,S,I,Q,R,D,CR,V,VaccPeriod,MaxHealthCare)
% This function evaluates the cost function
    global N
    VaccinePrice = 1; % this is assumed
    VaccineTotalPeople = 0; % number of people getting vaccinated on peroid-i
    VaccineTotalPeople_prev = 0; % number of people getting vaccinated on peroid-(i-1). ...
    %This is defined since we have cummulative vaccinated people. So, to
    %calculate #vaccinated person in period i, we simply can calculate the
    %difference.
    tspan = 1:1:31;
    for j = 1 : VaccPeriod
        y0 = [N-I(end)-R(end)-Q(end)-D(end),I(end),Q(end),R(end),D(end),CR(end),V(end)]; %simulation
        [t,y] = ode45(@(t,y) system_function(t,y,v(j)), tspan, y0);
        S = [S;y(2:end,1)]; 
        I = [I;y(2:end,2)]; 
        Q = [Q;y(2:end,3)]; 
        R = [R;y(2:end,4)]; 
        D = [D;y(2:end,5)];
        CR = [CR;y(2:end,6)];
        V = [V;y(2:end,7)];
        VaccineTotalPeople = VaccineTotalPeople + V(end) - VaccineTotalPeople_prev; %calculating the vaccinated person
        VaccineTotalPeople_prev = V(end);
    end
    if (max(Q) > MaxHealthCare) || (I(end)>200) %omitting the unfeasible solution
        VaccineTotalCost = 1e100; % by making the VaccineTotalCost as large as possible
    else
        VaccineTotalCost = VaccinePrice*V(end);  
    end
end